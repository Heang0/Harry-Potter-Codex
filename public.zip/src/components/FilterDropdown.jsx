function FilterDropdown({ value, onChange, options, label }) {
  return (
    <label className="flex flex-col text-xs uppercase tracking-[0.2em] text-[#f5f0e3]/60">
      {label}
      <select
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="mt-2 rounded-full border border-white/10 bg-black/40 px-4 py-2 text-sm text-ivory focus:border-[#c4a867]/60 focus:outline-none"
      >
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </label>
  )
}

export default FilterDropdown

