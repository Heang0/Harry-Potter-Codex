import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Search } from 'lucide-react';
import DarkModeToggle from './DarkModeToggle';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { name: 'Home', path: '/' },
    { name: 'Characters', path: '/characters' },
    { name: 'Houses', path: '/houses' },
    { name: 'Spells', path: '/spells' },
    { name: 'Courses', path: '/courses' },
    { name: 'Timeline', path: '/timeline' },
    { name: 'About', path: '/about' },
  ];

  const isActive = (path) => location.pathname === path;

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled
        ? 'bg-ink/95 backdrop-blur-md border-b border-[#c4a867]/20 shadow-lg'
        : 'bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-3 group">
            <div className="w-10 h-10 bg-gold rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
              <span className="text-ink font-bold text-xl">HC</span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-ivory group-hover:text-gold transition-colors duration-300">
                Hogwarts Codex
              </h1>
              <p className="text-xs text-[#f5f0e3]/60 mt-1 hidden md:block">
                The Official Wizarding Archive
              </p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`relative font-medium text-sm uppercase tracking-[0.1em] transition-colors duration-300 ${
                  isActive(item.path)
                    ? 'text-gold'
                    : 'text-[#f5f0e3]/80 hover:text-ivory'
                }`}
              >
                {item.name}
                {isActive(item.path) && (
                  <span className="absolute -bottom-1 left-0 w-full h-0.5 bg-gold rounded-full"></span>
                )}
              </Link>
            ))}

            <button className="inline-flex items-center gap-2 rounded-full border border-[#c4a867]/60 bg-[#1a1f2e] px-4 py-2 text-xs font-semibold uppercase tracking-[0.2em] text-gold transition-all duration-300 hover:-translate-y-0.5 border-[#c4a867]/60 bg-[#1a1f2e] hover:border-[#c4a867] hover:bg-[#2a2f3e] box-shadow: 0 4px 15px rgba(196, 168, 103, 0.2);">
              <Search className="w-4 h-4" />
              <span className="hidden md:inline">Search</span>
            </button>

            <DarkModeToggle />
          </nav>

          {/* Mobile Menu Button */}
          <div className="flex items-center space-x-2">
            <DarkModeToggle />
            <button
              className="md:hidden p-2 rounded-lg hover:bg-[#1a1f2e]/50 transition-colors"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              aria-label="Toggle menu"
            >
              {isMenuOpen ? (
                <X className="w-6 h-6 text-ivory" />
              ) : (
                <Menu className="w-6 h-6 text-ivory" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-[#c4a867]/20 animate-slide-up">
            <div className="flex flex-col space-y-3">
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`px-4 py-3 rounded-lg text-sm font-medium uppercase tracking-[0.1em] transition-colors ${
                    isActive(item.path)
                      ? 'bg-[#c4a867]/10 text-gold'
                      : 'text-[#f5f0e3]/80 hover:text-ivory hover:bg-[#1a1f2e]/50'
                  }`}
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item.name}
                </Link>
              ))}
              <button className="inline-flex items-center gap-2 rounded-full border border-[#c4a867]/60 bg-[#1a1f2e] px-4 py-2 text-xs font-semibold uppercase tracking-[0.2em] text-gold transition-all duration-300 hover:-translate-y-0.5">
                <Search className="w-4 h-4" />
                <span>Search</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;