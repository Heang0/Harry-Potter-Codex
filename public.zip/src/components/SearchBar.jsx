function SearchBar({ value, onChange, placeholder = 'Search...' }) {
  return (
    <input
      className="w-full rounded-full border border-white/10 bg-black/40 px-4 py-2 text-sm text-ivory placeholder:text-[#f5f0e3]/40 focus:border-[#c4a867]/60 focus:outline-none"
      value={value}
      onChange={(event) => onChange(event.target.value)}
      placeholder={placeholder}
    />
  )
}

export default SearchBar

