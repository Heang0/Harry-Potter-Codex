import { Outlet } from 'react-router-dom';
import ProfessionalNavBar from './ProfessionalNavBar';

const PageLayout = () => {
  return (
    <div className="min-h-screen">
      {/* Main Content */}
      <main className="relative z-10">
        <div className="container-max py-8">
          <ProfessionalNavBar />
          <Outlet />
        </div>
      </main>
    </div>
  );
};

export default PageLayout;