import { Link } from 'react-router-dom';

const CharacterCard = ({ character }) => {
  const getHouseColor = (house) => {
    switch (house.toLowerCase()) {
      case 'gryffindor': return 'bg-red-600/20 text-red-300 border-red-500/30';
      case 'slytherin': return 'bg-green-600/20 text-green-300 border-green-500/30';
      case 'ravenclaw': return 'bg-blue-600/20 text-blue-300 border-blue-500/30';
      case 'hufflepuff': return 'bg-yellow-600/20 text-yellow-300 border-yellow-500/30';
      default: return 'bg-gray-600/20 text-gray-300 border-gray-500/30';
    }
  };

  return (
    <Link 
      to={`/characters/${character.id}`}
      className="card-glow group block hover:shadow-[0_40px_100px_rgba(196,168,103,0.2)] transition-all duration-300"
    >
      <div className="flex items-start space-x-4">
        {/* Character Image Placeholder */}
        <div className="w-20 h-20 bg-ink rounded-xl flex-shrink-0 overflow-hidden border border-[#c4a867]/20">
          <div className="w-full h-full bg-gradient-to-br from-[#c4a867]/10 to-[#1a1f2e] flex items-center justify-center">
            <span className="text-[#c4a867]/50 text-lg font-bold">
              {character.name?.charAt(0) || '?'}
            </span>
          </div>
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-xl font-bold text-ivory group-hover:text-gold transition-colors">
              {character.name}
            </h3>
            <span className={`badge px-3 py-1 text-xs font-medium ${getHouseColor(character.house)}`}>
              {character.house}
            </span>
          </div>
          
          <p className="text-[#f5f0e3]/70 text-sm mb-3 line-clamp-2">
            {character.description || 'Magical expert and accomplished wizard'}
          </p>
          
          <div className="flex items-center space-x-4 text-xs">
            <span className="text-[#f5f0e3]/60 flex items-center">
              🪄 {character.magicalAbility || 'Advanced Magic'}
            </span>
            <span className="text-[#f5f0e3]/60 flex items-center">
              📚 {character.role || 'Professor'}
            </span>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default CharacterCard;