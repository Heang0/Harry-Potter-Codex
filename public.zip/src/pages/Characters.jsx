import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import CharacterCard from '../components/CharacterCard';

// Mock character data - replace with actual API calls in production
const mockCharacters = [
  {
    id: 1,
    name: "Albus Dumbledore",
    house: "Gryffindor",
    description: "Headmaster of Hogwarts School of Witchcraft and Wizardry, widely considered to be the greatest wizard of modern times.",
    magicalAbility: "Transfiguration Master",
    role: "Headmaster"
  },
  {
    id: 2,
    name: "Harry Potter",
    house: "Gryffindor",
    description: "The Boy Who Lived, famous for surviving the Killing Curse as a baby and defeating Lord Voldemort.",
    magicalAbility: "Defensive Magic",
    role: "Student"
  },
  {
    id: 3,
    name: "Hermione Granger",
    house: "Gryffindor",
    description: "Exceptionally intelligent witch known for her academic excellence and logical thinking.",
    magicalAbility: "Charms Expert",
    role: "Student"
  },
  {
    id: 4,
    name: "Severus Snape",
    house: "Slytherin",
    description: "Potions Master and later Headmaster of Hogwarts, known for his complex loyalties and mastery of Dark Arts.",
    magicalAbility: "Potion Brewing",
    role: "Professor"
  },
  {
    id: 5,
    name: "Minerva McGonagall",
    house: "Gryffindor",
    description: "Transfiguration professor and Deputy Headmistress, known for her strict discipline and fairness.",
    magicalAbility: "Animagus Transformation",
    role: "Professor"
  },
  {
    id: 6,
    name: "Draco Malfoy",
    house: "Slytherin",
    description: "Slytherin student from a wealthy pure-blood family, initially antagonistic but showing complexity over time.",
    magicalAbility: "Advanced Spellcasting",
    role: "Student"
  },
  {
    id: 7,
    name: "Luna Lovegood",
    house: "Ravenclaw",
    description: "Eccentric Ravenclaw student known for her unique perspective and belief in magical creatures.",
    magicalAbility: "Creature Recognition",
    role: "Student"
  },
  {
    id: 8,
    name: "Neville Longbottom",
    house: "Gryffindor",
    description: "Initially clumsy student who grows into a brave and skilled wizard, becoming a Herbology professor.",
    magicalAbility: "Herbology Expert",
    role: "Student"
  }
];

const Characters = () => {
  const [characters, setCharacters] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedHouse, setSelectedHouse] = useState('All');

  useEffect(() => {
    // In a real app, this would be an API call
    setCharacters(mockCharacters);
  }, []);

  const houses = ['All', 'Gryffindor', 'Slytherin', 'Ravenclaw', 'Hufflepuff'];
  
  const filteredCharacters = characters.filter(character => {
    const matchesSearch = character.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         character.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesHouse = selectedHouse === 'All' || character.house === selectedHouse;
    return matchesSearch && matchesHouse;
  });

  return (
    <div className="pt-20 pb-16">
      {/* Header */}
      <div className="container-max mb-12">
        <div className="text-center mb-8">
          <h1 className="headline">Wizarding World Characters</h1>
          <p className="lead max-w-2xl mx-auto">
            Explore detailed profiles of witches and wizards from the magical world, from legendary founders to modern-day students.
          </p>
        </div>

        {/* Search and Filter */}
        <div className="card-glow p-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="relative flex-1">
              <input
                type="text"
                placeholder="Search characters..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full px-6 py-3 bg-black/40 border border-[#c4a867]/20 rounded-full text-ivory placeholder-[#f5f0e3]/50 focus:outline-none focus:border-gold focus:ring-2 focus:ring-gold/20"
              />
              <div className="absolute right-3 top-1/2 transform -translate-y-1/2 text-[#f5f0e3]/50">
                🔍
              </div>
            </div>
            
            <div className="flex space-x-2">
              {houses.map((house) => (
                <button
                  key={house}
                  onClick={() => setSelectedHouse(house)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    selectedHouse === house
                      ? 'bg-gold text-ink'
                      : 'bg-ink/50 text-[#f5f0e3]/70 hover:text-ivory'
                  }`}
                >
                  {house}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Characters Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mt-8">
          {filteredCharacters.length > 0 ? (
            filteredCharacters.map((character) => (
              <CharacterCard key={character.id} character={character} />
            ))
          ) : (
            <div className="col-span-full text-center py-16">
              <div className="text-6xl mb-4">🔍</div>
              <h3 className="text-2xl font-bold text-ivory mb-2">No characters found</h3>
              <p className="text-[#f5f0e3]/70">Try adjusting your search terms or filter criteria.</p>
            </div>
          )}
        </div>

        {/* Stats */}
        <div className="mt-12 pt-8 border-t border-[#c4a867]/20">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-gold mb-2">{characters.length}</div>
              <div className="text-[#f5f0e3]/70 text-sm">Characters</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-amber mb-2">4</div>
              <div className="text-[#f5f0e3]/70 text-sm">Houses</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-deep-blue mb-2">12</div>
              <div className="text-[#f5f0e3]/70 text-sm">Professors</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-crimson mb-2">89</div>
              <div className="text-[#f5f0e3]/70 text-sm">Students</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Characters;